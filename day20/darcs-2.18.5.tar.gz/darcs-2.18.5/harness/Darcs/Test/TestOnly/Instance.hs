{-# OPTIONS_GHC -Wno-orphans #-}
module Darcs.Test.TestOnly.Instance where

import Darcs.Test.TestOnly

instance TestOnly
