Please consult <http://darcs.net/Development/RegressionTests>.
