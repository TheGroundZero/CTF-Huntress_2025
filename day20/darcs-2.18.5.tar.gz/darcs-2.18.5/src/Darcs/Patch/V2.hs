module Darcs.Patch.V2 ( RepoPatchV2 ) where

import Darcs.Patch.V2.RepoPatch ( RepoPatchV2 )
