-- | XXX: Perhaps a word of explanation here [WL]
module Darcs.Util.Ratified
    (
      readFile
    , hGetContents
    ) where

import System.IO ( hGetContents, readFile )
