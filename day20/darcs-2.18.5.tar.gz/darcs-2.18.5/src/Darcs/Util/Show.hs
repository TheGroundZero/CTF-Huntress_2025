module Darcs.Util.Show ( appPrec ) where

import Darcs.Prelude

appPrec :: Int
appPrec = 10
