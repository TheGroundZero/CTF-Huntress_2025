int maybe_relink(const char *src, const char *dst, int careful);
