int set_umask(char *mask_string);
int reset_umask(int old_mask);
